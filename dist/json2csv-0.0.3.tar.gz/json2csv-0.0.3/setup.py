from setuptools import setup

setup(
    name='json2csv',
    version='0.0.3',
    description='Library for converting JSON to CSV',
    author='Ed',
    author_email='agabsed@gmail.com',
    packages=['json2csv'],
    install_requires=['json', 'csv'],
)
